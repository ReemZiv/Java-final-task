/**
 * This class represents a node of a rent in a list of rents
 * @author Reem Ziv
 * @version 20-01-2023
 */
public class RentNode{
    //declarations
    private Rent _rent;
    private RentNode _next;
    
    //Constructors
    /**
     * Creates a new rent node having only the rent, _next will be null
     * @param r the rent
     */
    public RentNode (Rent r){
        _rent = new Rent(r);
        _next = null;
    }
    
    /**
     * Creates a new rent node having both the rent and the next rent
     * @param r the rent
     * @param next the next node of this rent
     */
    public RentNode(Rent r, RentNode next){
        _rent = new Rent(r);
        _next = next;
    }
    
    /**
     * Copy constructor
     * @param other the rent to be copied
     */
    public RentNode(RentNode other){
        _rent = new Rent(other._rent);
        _next = other._next;
    }
    
    //Methods
    /**
     * Gets the rent
     * @return the rent
     */
    public Rent getRent(){
        return new Rent(_rent);
    }
    
    /**
     * Gets the next rent
     * @return the next node of this rent
     */
    public RentNode getNext(){
        return _next;
    }
    
    /**
     * Sets the rent
     * @param r the rent to be set
     */
    public void setRent(Rent r){
        _rent = new Rent(r);
    }
    
    /**
     * Sets the next node of this rent 
     * @param next the next node to be setted
     */
    public void setNext(RentNode next){
        _next = next;
    }
}