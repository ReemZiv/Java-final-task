/**
 * This class represents a company of car rents
 * @author Reem Ziv
 * @version 27-01-2023
 */
public class Company{
    //declarations
    private RentNode _head; //The first rent node
    
    //Constructors
    /**
     * Creates a new empty company
     */
    public Company(){
        _head = null;
    }
    
    //Methods
    /**
     * Adding a rent node to the company in the right space.
     * The rents need to be sorted by their pick dates. If there are a few rents with the same pick Date, the longest rent will be first.
     * You can assume that there aren't two different rents with the same pick Date and returnDate.
     * @param name the client's name
     * @param car the rented car
     * @param pick the pickup date
     * @param ret the return date
     * @return true if the rent was added successfully, false if there was already the same rent in the company and it didn't add this rent.
     */
    public boolean addRent(String name, Car car, Date pick, Date ret){
        RentNode rent = new RentNode(new Rent(new String(name),new Car(car), new Date(pick),new Date(ret)));
        if(_head == null){ //Checking if the company is empty
            _head = rent;
            return true;
        }
        
        RentNode temp = _head;
        RentNode before = temp;
        while(temp != null && pick.after(temp.getRent().getPickDate())){
            before = temp;
            temp = temp.getNext();
        }
        
        while(temp != null && pick.equals(temp.getRent().getPickDate()) && rent.getRent().howManyDays() < temp.getRent().howManyDays()){
            before = temp;
            temp = temp.getNext();
        }
        
        if(temp != null && rent.getRent().equals(temp.getRent()))
            return false;
        
        if(temp == _head){ //Takes care if the rent should be the first
            _head = rent;
            rent.setNext(temp);
            return true;
        }
        
        before.setNext(rent);
        rent.setNext(temp);
        return true;
    }
    
    /**
     * Removing the first rent that it's return Date is the same as the one given from the company.
     * @param ret the return date of the rent we want to remove
     * @return true if the rent was successful, false if the return date isn't found in the company or if the company is empty
     */
    public boolean removeRent(Date ret){
        if(_head == null)
            return false;
        RentNode temp = _head;
        RentNode before = temp;
        while(temp != null && !ret.equals(temp.getRent().getReturnDate())){ //Going in the company until we find the rent we want to remove or until we got to the end
            before = temp;
            temp = temp.getNext();
        }
        
        if(temp == null) //Returns false if the rent wasn't found
            return false;
            
        if(temp == _head){ //If the client wants to remove the _head
            _head = _head.getNext();
            return true;
        }
        before.setNext(temp.getNext()); //Removing the rent
        return true;
    }
    
    /**
     * Counts the number of the rents in the company
     * @return number of the rents in the company
     */
    public int getNumOfRents(){
        int count = 0;
        RentNode temp = _head;
        while(temp != null){
            count++;
            temp = temp.getNext();
        }
        return count;
    }
    
    /**
     * Calculates the sum of the prices of all the rents in the company
     * @return the sum of the prices of all the rents in the company
     */
    public int getSumOfPrices(){
        int sum = 0;
        RentNode temp = _head;
        while(temp != null){
            sum += temp.getRent().getPrice();
            temp = temp.getNext();
        }
        return sum;
    }
    
    /**
     * Calculates the total number of the rent days in the company
     * @return the total number of the rent days in the company
     */
    public int getSumOfDays(){
        int sum = 0;
        RentNode temp = _head;
        while(temp != null){
            sum += temp.getRent().howManyDays();
            temp = temp.getNext();
        }
        return sum;
    }
    
    /**
     * Calculates the average rent days. If the company is empty, it returns 0
     * @return the average rent days or 0 if the company is empty
     */
    public double averageRent(){
        if(_head == null)
            return 0;
        return (double)getSumOfDays() / getNumOfRents();
    }
    
    /**
     * Finds the car with the latest return date. If there is more than one car with the same latest rent, the method returns the first in the company order.
     * @return the first(in the company order) car in the company with the latest return date
     */
    public Car lastCarRent(){
        if(_head == null)
            return null;
        RentNode temp = _head;
        Car lastCar = new Car(_head.getRent().getCar());
        Date lastDate = new Date(_head.getRent().getReturnDate());
        while(temp != null){
            if(temp.getRent().getReturnDate().after(lastDate)){
                lastCar = new Car(temp.getRent().getCar());
                lastDate = new Date(temp.getRent().getReturnDate());
            }
            temp = temp.getNext();
        }
        
        return new Car(lastCar);
    }
    
    /**
     * Finds the rent with the longest length. If there are a few rents with the longest length, the method returns the first in the company order.
     * @return the first(in the company order) rent with longest length.
     */
    public Rent longestRent(){
        if(_head == null)
            return null;
        RentNode temp = _head;
        Rent longest = new Rent(_head.getRent());
        while(temp != null){
            if(temp.getRent().howManyDays() > longest.howManyDays()){
                longest = new Rent(temp.getRent());
            }
            temp = temp.getNext();
        }
        return new Rent(longest);
    }
    
    /**
     * Returns the most common car rate in the company. If there are a few rates with the same frequency, the method returns the highest rate('B' > 'A' for example).
     * If the company is empty, the method returns 'N'.
     * @return the highest and most common car rate in the company
     */
    public char mostCommonRate(){
        int countA = 0, countB = 0, countC = 0, countD = 0; //First, setting all the counts to 0
        if(_head == null)
            return 'N';
            
        RentNode temp = _head;
        while(temp != null){
            switch(temp.getRent().getCar().getType()){
                case 'A':
                    countA++;
                    break;
                case 'B':
                    countB++;
                    break;
                case 'C':
                    countC++;
                    break;
                case 'D':
                    countD++;
                    break;
            }
            temp = temp.getNext();
        }
        
        int max = Math.max(Math.max(countA,countB),Math.max(countC,countD)); //Finds the most common rate and then returns the highest rate with the same count.
        if(countD == max)
            return 'D';
        else if(countC == max)
            return 'C';
        else if(countB == max)
            return 'B';
        else 
            return 'A';
    }
    
    /**
     * Returns if this company contains completely another company.
     * If the given company is empty, the method returns true.
     * If this company is empty, the method returns false.
     * @param other the company to be checked. 
     * @return true if the company contains completely another company or if the given company is empty, false if the company doesn't fully contains the other company or if this company is empty.
     */
    public boolean includes(Company other){
        if(other._head == null)
            return true;
        if(_head == null)
            return false;
            
        RentNode cur = _head;
        RentNode temp = other._head;
        
        while(cur != null && temp != null){
            if(cur.getRent().equals(temp.getRent())) //If a rent in this company equals to a rent in the other company, we move forward in the other company until we get to the end of one of the companies
                temp = temp.getNext();
            cur = cur.getNext();
        }
        
        if(temp == null) //If we got to the end of the other company, it means that each rent of the other company exits in this company 
            return true;
        return false;
    }
    
    /**
     * Merges this company and other company into this company while keeping the correct order using the pick date as described in the "add rent" method.
     * You can assume that there aren't two different rents with the same pick Date and return Date.
     * @param other the company to be merged with this company
     */
    public void merge(Company other){
        if(_head == null){ //If this company is empty, the new head is the other's.
            _head = other._head;
            return;
        }
        
        if(other._head == null) //If the other company is empty no change need to be done.
            return;
        
        //The next lines check if the other company's _head needs to be before this head, if it is, the method replaces between the companies - this company will become the other and the other company will become this.
        if(_head.getRent().getPickDate().after(other._head.getRent().getPickDate()) || (_head.getRent().getPickDate().equals(other._head.getRent().getPickDate())) && (_head.getRent().getReturnDate().before(other._head.getRent().getReturnDate()))){
            RentNode cur = _head;
            _head = other._head;
            other._head = cur;
        }
        
        //The next lines check if this company's head is the same as the other's, if they are we move the other's head to the next rent because we don't need the other's head anymore.
        if(other._head.getRent().equals(_head.getRent()))
            other._head = other._head.getNext();
            
        RentNode temp = _head.getNext(), otherTemp = other._head; //Temp will be the rent we will add to before, and otherTemp will be the current rent in the other company.
        RentNode before = _head;
        while(temp != null && otherTemp != null){
            //First, we check if the other company's rent need to be the next in order
            if((temp.getRent().getPickDate().after(otherTemp.getRent().getPickDate()))
            || ((temp.getRent().getPickDate().equals(otherTemp.getRent().getPickDate())) && (temp.getRent().getReturnDate().before(otherTemp.getRent().getReturnDate())))){
                //If it is, we replace between temp and otherTemp 
                RentNode replace = temp;
                temp = otherTemp;
                otherTemp = replace;
                System.out.println(temp.getRent());
                System.out.println(otherTemp.getRent());
            }
            
            //Then, we check if temp and otherTemp have the same rent, if they do we move otherTemp next, so we don't have the same rent twice
            if(temp.getRent().equals(otherTemp.getRent()))
                otherTemp = otherTemp.getNext();
            //Last, we set the next rent and move before and temp next.
            before.setNext(temp);
            before = before.getNext();
            temp = temp.getNext();
        }
        
        if(otherTemp != null) //If there are still more rents in one of the companies, we add them to this company.
            before.setNext(otherTemp);
    }
    
    /**
     * Returns a string that describes all the rents in this company in a specific format.
     * @return a string that describes all the rents in this company in a specific format
     */
    public String toString(){
        if(_head == null)
            return "The company has 0 rents.";
        String result = "";
        result += "The company has " + getNumOfRents() + " rents:\n";
        RentNode temp = _head;
        while(temp != null){
            result += temp.getRent() + "\n";
            temp = temp.getNext();
        }
        return result;
    }
}